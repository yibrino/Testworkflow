from setuptools import setup, find_packages

setup(
    name='intermediate_test_dummy_package',
    version='1.0.0',
    packages=['intermediate_test_app'],
    install_requires=[],
)
