def very_complex_logic(*args):
    return sum(args)
