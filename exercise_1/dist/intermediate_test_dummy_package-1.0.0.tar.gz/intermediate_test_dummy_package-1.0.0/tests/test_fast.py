from intermediate_test_app import very_complex_logic


def test_complex_logic_very_very_fast():
    assert very_complex_logic(1, 2, 3) == 6
